package com.ihsanmkls.storyapp.data.api

data class StoryResponse(
    val error: Boolean,
    val message: String,
    val listStory: ArrayList<Story>
)
