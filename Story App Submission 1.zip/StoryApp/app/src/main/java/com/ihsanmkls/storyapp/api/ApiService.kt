package com.ihsanmkls.storyapp.api

import com.ihsanmkls.storyapp.data.api.*
import okhttp3.MultipartBody
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.http.*

interface ApiService {
    @POST("register")
    fun userRegister(@Body register: Register): Call<GeneralResponse>

    @POST("login")
    fun userLogin(@Body login: Login): Call<LoginResponse>

    @GET("stories")
    fun getAllStories(@Header("Authorization") token: String): Call<StoryResponse>

    @Multipart
    @POST("stories")
    fun addNewStory(
        @Header("Authorization") token: String,
        @Part("description") description: RequestBody,
        @Part file: MultipartBody.Part
    ): Call<GeneralResponse>
}