package com.ihsanmkls.storyapp.data.api

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Register (
    var name: String?,
    var email: String?,
    var password: String?
) : Parcelable