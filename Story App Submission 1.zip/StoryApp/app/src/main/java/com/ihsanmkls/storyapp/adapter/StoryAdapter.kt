package com.ihsanmkls.storyapp.adapter

import android.app.Activity
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.app.ActivityOptionsCompat
import androidx.recyclerview.widget.RecyclerView
import androidx.core.util.Pair
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.ihsanmkls.storyapp.data.api.Story
import com.ihsanmkls.storyapp.databinding.ItemRowStoryBinding
import com.ihsanmkls.storyapp.view.story.DetailStoryActivity

class StoryAdapter : RecyclerView.Adapter<StoryAdapter.StoryViewHolder>() {

    private var listStory = ArrayList<Story>()

    inner class StoryViewHolder(private val binding: ItemRowStoryBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(data: Story) {
            itemView.setOnClickListener{
                val intent = Intent(itemView.context, DetailStoryActivity::class.java)
                intent.putExtra("Story", data)
                val optionsCompat: ActivityOptionsCompat =
                    ActivityOptionsCompat.makeSceneTransitionAnimation(
                        itemView.context as Activity,
                        Pair(binding.photoStory, "photo"),
                        Pair(binding.authorTextView, "name"),
                        Pair(binding.descriptionTextView, "description")
                    )
                itemView.context.startActivity(intent, optionsCompat.toBundle())
            }

            binding.apply {
                Glide.with(itemView)
                    .load(data.photoUrl)
                    .centerCrop()
                    .transition(DrawableTransitionOptions.withCrossFade())
                    .into(photoStory)
                authorTextView.text = data.name
                descriptionTextView.text = data.description
            }

        }
    }

    fun setListStory(listStory: ArrayList<Story>) {
        this.listStory = listStory
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): StoryViewHolder {
        val view = ItemRowStoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return StoryViewHolder(view)
    }

    override fun onBindViewHolder(holder: StoryViewHolder, position: Int) {
        holder.bind(listStory[position])
    }

    override fun getItemCount(): Int = listStory.size
}