package com.ihsanmkls.storyapp.data.api

data class User(
    val isLogin: Boolean,
    val userId: String,
    val name: String,
    val token: String
)