package com.ihsanmkls.storyapp.view.main

import android.util.Log
import androidx.lifecycle.*
import com.ihsanmkls.storyapp.api.ApiConfig
import com.ihsanmkls.storyapp.data.UserPreferences
import com.ihsanmkls.storyapp.data.api.Story
import com.ihsanmkls.storyapp.data.api.StoryResponse
import com.ihsanmkls.storyapp.data.api.User
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainViewModel(private val pref: UserPreferences) : ViewModel() {

    private val _listStory = MutableLiveData<ArrayList<Story>?>()
    val listStory: LiveData<ArrayList<Story>?> = _listStory

    fun getStories(tokenAuth: String) {
        Log.d(this@MainViewModel::class.java.simpleName, tokenAuth)
        ApiConfig.getApiService().getAllStories(token = "Bearer $tokenAuth").enqueue(object : Callback<StoryResponse> {
                override fun onResponse(
                    call: Call<StoryResponse>,
                    response: Response<StoryResponse>
                ) {
                    if (response.isSuccessful) {
                        _listStory.postValue(response.body()?.listStory)
                    } else {
                        _listStory.postValue(null)
                        Log.e(TAG, "onFailure: ${response.message()}")
                    }
                }
                override fun onFailure(call: Call<StoryResponse>, t: Throwable) {
                    _listStory.postValue(null)
                    Log.d(TAG, "onFailure: ${t.message.toString()}")
                }
            })
    }

    fun getUser(): LiveData<User> {
        return pref.getUser().asLiveData()
    }

    fun logout() {
        viewModelScope.launch {
            pref.logout()
        }
    }

    companion object{
        private const val TAG = "MainViewModel"
    }

}