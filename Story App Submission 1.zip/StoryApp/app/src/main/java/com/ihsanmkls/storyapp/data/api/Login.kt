package com.ihsanmkls.storyapp.data.api

import android.os.Parcelable
import kotlinx.parcelize.Parcelize


@Parcelize
data class Login(
    var email: String?,
    var password: String?
) : Parcelable
