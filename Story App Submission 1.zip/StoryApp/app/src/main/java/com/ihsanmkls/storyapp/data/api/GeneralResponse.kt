package com.ihsanmkls.storyapp.data.api

data class GeneralResponse (
    val error: Boolean,
    val message: String
)